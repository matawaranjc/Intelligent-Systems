Code Instruction:

1. Open HW2_Report.py file in python editor like pycharm.
2. Place the data sets in the same location of the code file.
3. Run/Execute the code.
4. The graphs will be shown.

Note: In pycharm the graphs will pop up one by one. 

If you have any questions please contact me at matawajc@mail.uc.edu