################### IMPORTS ###################

import random
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split

################### PROBLEM NUMBER 1 ###################

################### LOAD THE DATA ###################

dataComplete = pd.read_csv("MNIST_COMPLETE.csv")
xData = np.array(dataComplete.iloc[:, :-1])
yData = np.array(dataComplete.iloc[:, -1])

xTrain, xTest, yTrain, yTest = train_test_split(xData, yData, train_size=0.8)
trainBias = np.ones((len(yTrain), 1))
testBias = np.ones((len(xTest), 1))

################### BIAS ON THE INPUT ###################

xTrain = np.append(xTrain, trainBias, axis=1)
xTest =  np.append(xTest, testBias, axis=1)

print("NUMBER OF HIDDEN NEURONS: ")
neuronsNum = int(input())

def sigmoidActivation(x):
    return 1 / (1 + np.exp(-x))

def sigmoidDer(act):
    act = sigmoidActivation(act)
    dS = act * (1 - act)
    return dS

################### PREPARATION OF DATA ###################

weightVectorIP = np.random.randn(785, neuronsNum)
weightVectorHid = np.random.randn(neuronsNum, 10)

################### ONE HOT ENCODING ###################

trainFinalY = np.zeros((len(yTrain), 10))
for j in range(0, len(yTrain)):
    trainFinalY[j][yTrain[j]] = 1

testFinalY = np.zeros((len(yTest), 10))
for j in range(0, len(yTest)):
    testFinalY[j][yTest[j]] = 1

################### NETWORK TRAINING ###################

eta = 0.001
epochs = 750
alpha = 0.2
momentum = 1
errorFractionTrain = []
errorFractionTest = []

for epo in range(0, epochs):
    cntTrain = 0
    cntTest = 0
    k = 0
    t = 0
    ################### FORWARD PASS ###################

    ################### CALCULATION FROM WEIGHTS ###################

    stTrainhidIn = np.dot(xTrain, weightVectorIP)

    ################### SIGMOID ACTIVATION ###################

    HidOp = sigmoidActivation(stTrainhidIn)

    ################### HIDDEN WEIGHTS CALCULATION ###################

    stTrainHidOp = np.dot(HidOp, weightVectorHid)

    ################### SIGMOID ACTIVATION FOR OUTPUT LAYER ###################

    tempHATY = sigmoidActivation(stTrainHidOp)
    hatY = np.argmax(tempHATY, axis=1)
    
    ################### BACK-PROPAGATION ###################-
    w2Delta = np.dot(HidOp.T,
                     (trainFinalY - tempHATY) * sigmoidDer(
                         np.dot(HidOp, weightVectorHid)))
    DW2Temp = w2Delta

    w1Delta = np.dot(xTrain.T, np.dot((trainFinalY - tempHATY) * sigmoidDer(np.dot(HidOp, weightVectorHid)), weightVectorHid.T) * (sigmoidDer(np.dot(xTrain, weightVectorIP))))
    w1Temp = w1Delta

    weightVectorHid = weightVectorHid + eta * w2Delta
    weightVectorIP = weightVectorIP + eta * w1Delta

    ################### L AND H IMPLEMENTATION ###################
    for itr in range(0, len(tempHATY)):
        for l in range(0,10):
            if tempHATY[itr][l]>= 0.75:
                tempHATY[itr][l] = 1
            elif tempHATY[itr][l] <= 0.25:
                tempHATY[itr][l] = 0


    ################### NETWORK TESTING ###################

    ################### CALCULATION FROM WEIGHTS ###################

    trainInputHidTest = np.dot(xTest, weightVectorIP)

    ################### SIGMOID ACTIVATION ###################

    testHidO = sigmoidActivation(trainInputHidTest)

    ################### HIDDEN WEIGHTS CALCULATION ###################

    trainHidoTest = np.dot(testHidO, weightVectorHid)

    ################### SIGMOID ACTIVATION FOR OUTPUT LAYER ###################

    TestyHatTemp = sigmoidActivation(trainHidoTest)
    Testyhat = np.argmax(TestyHatTemp, axis=1)

    for itr in range(0, len(TestyHatTemp)):
        for l in range(0,10):
            if tempHATY[itr][l]>= 0.75:
                tempHATY[itr][l] = 1
            elif tempHATY[itr][l] <= 0.25:
                tempHATY[itr][l] = 0

    if epo%10 == 0:
        print("Epoch:", epo)
        for l, m in zip(trainFinalY, tempHATY):
            k += sum((l - m) ** 2)
            if np.argmax(l) != np.argmax(m):
                cntTrain+=1
        k = k / len(trainFinalY)
        TrainError = cntTrain / len(trainFinalY)
        print("Train-Loss: ",k)
        print("Train Error-Fraction: ", TrainError)
        errorFractionTrain.append(TrainError)

        for l, m in zip(testFinalY, TestyHatTemp):
            t += sum((l - m) ** 2)
            if np.argmax(l) != np.argmax(m):
                cntTest += 1
        t = t / len(testFinalY)
        error_test = cntTest / len(testFinalY)
        print("Test-Loss: ", t)
        print("Test Error-Fraction: ", error_test)
        errorFractionTest.append(error_test)

################### CREATION OF GRAPHS ###################

confusionDf = confusion_matrix(yTrain, hatY)
plt.title("Training Data Confusion Matrix")
colormap = sns.color_palette("Greens")
ax = sns.heatmap(confusionDf, cmap=colormap, annot=True, cbar=False, fmt=".1f")
ax.xaxis.set_ticks_position('top')
plt.show()

confusionDf = confusion_matrix(yTest, Testyhat)
plt.title("Testing Data Confusion Matrix")
colormap = sns.color_palette("Greens")
ax = sns.heatmap(confusionDf, cmap=colormap, annot=True, cbar=False, fmt=".1f")
ax.xaxis.set_ticks_position('top')
plt.show()

plt.plot(np.arange(0,(epochs/10),1), errorFractionTrain, color="green", label="Training Error")
plt.plot(np.arange(0,(epochs/10),1), errorFractionTest, color="red", label="Testing Error")
plt.title("Epochs against Error Fractions")
plt.xlabel("Epochs")
plt.ylabel("Error Fractions")
plt.legend(loc="best")
plt.show()

################### PROBLEM NUMBER 2 ###################

data_complete_prob2 = pd.read_csv("MNIST_COMPLETE.csv")
weights_HW3 = np.array(pd.read_csv("WeightsH3.csv", header=None))
data_X = np.array(data_complete_prob2.iloc[:, :-1])
data_y = np.array(data_complete_prob2.iloc[:, -1])

train_X, test_X, train_y, test_y = train_test_split(data_X, data_y, train_size=0.8)
train_y = train_y.reshape(3999,1)
neurons_num = 146

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

################### PREPARATION OF DATA ###################

ip_hid_weight_vector = np.random.randn(784, neurons_num)
hid_op_weight_vector = np.random.randn(neurons_num, 784)
delta_weight1 = np.zeros((784, neurons_num))
delta_weight2 = np.zeros((neurons_num, 784))

################### NETWORK TRAINING ###################

epochs = 1000
alpha = 0.65
momentum = 1
error_train = []
eta = 0.001
e = []

for ep in range(0, epochs):
    k = 0
    t = 0

    ################### FORWARD PASS ###################
    trainInpST = np.dot(train_X, ip_hid_weight_vector)
    hidOp2 = sigmoid_activation(trainInpST)
    trainOpST = np.dot(hidOp2, hid_op_weight_vector)
    yhat_2 = sigmoid_activation(trainOpST)

    ################### BACK PROPAGATION ###################
    temp_dw2 = delta_weight2
    delta_weight2 = np.dot(hidOp2.T,
                           (train_X - yhat_2) * der_sigmoid(
                         np.dot(hidOp2, hid_op_weight_vector)))
    temp_dw1 = delta_weight1
    delta_weight1 = np.dot(train_X.T, np.dot((train_X - yhat_2) * der_sigmoid(np.dot(hidOp2, hid_op_weight_vector)),
                                             hid_op_weight_vector.T) * (der_sigmoid(np.dot(train_X, ip_hid_weight_vector))))
    hid_op_weight_vector = hid_op_weight_vector + (eta * delta_weight2)
    ip_hid_weight_vector = ip_hid_weight_vector + (eta * delta_weight1)

    if ep % 10 == 0:
        for l, m in zip(train_X, yhat_2):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Training-loss: ",k)

################### NETWORK TESTING ###################

trainInp_hid_testST = np.dot(test_X, ip_hid_weight_vector)
hid_op_test = sigmoid_activation(trainInp_hid_testST)
st_train_hid_op_test = np.dot(hid_op_test, hid_op_weight_vector)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nTest Loss (overall): ", t)

################### TRAINING AND TESTING ERRORS ###################
fig,axes = plt.subplots()
bar_plot = [(error_train[len(error_train)-1])/len(train_X), t]
bar_width = 0.5
axes.bar(1.5, bar_plot[0], color="g", width=0.5, label="Training Error")
axes.bar(1.5+bar_width, bar_plot[1], color="r", width=0.5, label="Testing Error")
plt.xlim(0,3)
axes.set_xlabel("Errors")
plt.suptitle("Training and Testing Errors")
plt.legend(loc="best")
plt.show()

################### FOR EACH DIGITS ###################
errors_train = []
errors_test = []

for i in range(0,10):
    locations = np.where(train_y == i)
    digit_data_train = train_X[locations[0],:]
    st_train_inp_hid_digit = np.dot(digit_data_train, ip_hid_weight_vector)
    hid_op_digit = sigmoid_activation(st_train_inp_hid_digit)
    st_train_hid_op_digit = np.dot(hid_op_digit, hid_op_weight_vector)
    yhat_digit = sigmoid_activation(st_train_hid_op_digit)
    digit_loss = np.sum(np.square(yhat_digit - digit_data_train))/len(digit_data_train)
    errors_train.append(digit_loss)

    digit_data_test = test_X[np.where(test_y == i)]
    st_test_inp_hid_digit = np.dot(digit_data_test, ip_hid_weight_vector)
    hid_op_digit_test = sigmoid_activation(st_test_inp_hid_digit)
    st_test_hid_op_digit = np.dot(hid_op_digit_test, hid_op_weight_vector)
    yhat_digit_test = sigmoid_activation(st_test_hid_op_digit)
    digit_loss_test = np.sum(np.square(yhat_digit_test-digit_data_test))/len(digit_data_test)
    errors_test.append(digit_loss_test)

fig,axes = plt.subplots()
bar_plot = [errors_train, errors_test]
indexes = np.arange(len(bar_plot[0]))
br1 = np.arange(len(bar_plot[0]))
br2 = [x + 0.25 for x in br1]
axes.bar(br1, bar_plot[0], color="g", width=0.25, label="Training Error")
axes.bar(br2, bar_plot[1], color="r", width=0.25, label="Testing Error")
axes.set_xticks(indexes+0.25)
axes.set_xticklabels(("0","1","2","3","4","5","6","7","8","9"))
axes.set_xlabel("Errors")
plt.ylabel("Errors")
plt.xlabel("Digits")
plt.suptitle("Training and Testing Errors of Digits 0-9")
plt.legend(loc="best")
plt.show()

################### TIME-SERIES ###################
plt.plot(e,error_train,color="green", label="Train Error")
plt.legend()
plt.grid()
plt.xlabel("Epochs")
plt.ylabel("Training Error")
plt.title("Epochs against Training Error")
plt.show()

################### FEATURES ###################
feature_samples = np.random.randint(low=0,high=142,size=(4,5),dtype=int)
fig, ax = plt.subplots(4, 5)
for i in range(0,4):
    for j in range(0,5):
        actual = hid_op_weight_vector[feature_samples[i][j]].reshape(28, 28).T
        plt_original = sns.heatmap(actual, ax=ax[i][j], square=True,cbar=False,xticklabels=False,cmap="Greens")
        ax[i][j].set_title("$Hidden-Neuron:$ %s"%feature_samples[i][j], fontsize = 6)
plt.suptitle("Auto-Encoder 20 Random Features from the Hidden Layer")
plt.show()

################### PROBLEM #1 FEATURES ###################
fig1, ax1 = plt.subplots(4, 5)
for i in range(0,4):
    for j in range(0,5):
        actual1 = weights_HW3[feature_samples[i][j]].reshape(28,28)
        plt_original1 = sns.heatmap(actual1, ax=ax1[i][j], square=True,cbar=False,xticklabels=False,cmap="Greens")
        ax1[i][j].set_title("$Hidden-Neuron:$ %s" % feature_samples[i][j], fontsize = 6)
plt.suptitle("Problem #1 20 random features from the hidden layer")
plt.show()


################### SAMPLE OUTPUT ###################
test_samples = random.sample(range(1000),8)
j = 0
fig, ax = plt.subplots(2, 8)
for k in range(0,8):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Greens")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Greens")
    if k==4:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")
plt.suptitle("Actual and Generated Images")
plt.show()

