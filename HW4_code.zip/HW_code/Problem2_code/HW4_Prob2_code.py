################### PROBLEM NUMBER 2 ###################


################### IMPORTS ###################

import random
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix

################### LOAD THE DATA ###################

complete_data = pd.read_csv("MNIST.csv")
weights_HW4 = np.array(pd.read_csv("Weights.csv",header=None))

data_0 = complete_data.loc[complete_data.iloc[:, -1] == 0]
data_1 = complete_data.loc[complete_data.iloc[:, -1] == 1]
data_2 = complete_data.loc[complete_data.iloc[:, -1] == 2]
data_3 = complete_data.loc[complete_data.iloc[:, -1] == 3]
data_4 = complete_data.loc[complete_data.iloc[:, -1] == 4]
data_5 = complete_data.loc[complete_data.iloc[:, -1] == 5]
data_6 = complete_data.loc[complete_data.iloc[:, -1] == 6]
data_7 = complete_data.loc[complete_data.iloc[:, -1] == 7]
data_8 = complete_data.loc[complete_data.iloc[:, -1] == 8]
data_9 = complete_data.loc[complete_data.iloc[:, -1] == 9]

################### TRAINING AND TESTING SETS ###################

data0_trainsubset = data_0.iloc[:400, :]
data1_trainsubset = data_1.iloc[:400, :]
data2_trainsubset = data_2.iloc[:400, :]
data3_trainsubset = data_3.iloc[:400, :]
data4_trainsubset = data_4.iloc[:400, :]

data0_testsubset = data_0.iloc[400:, :]
data1_testsubset = data_1.iloc[400:, :]
data2_testsubset = data_2.iloc[400:, :]
data3_testsubset = data_3.iloc[400:, :]
data4_testsubset = data_4.iloc[400:, :]

data5_subset = data_5.sample(n=100)
data6_subset = data_6.sample(n=100)
data7_subset = data_7.sample(n=100)
data8_subset = data_8.sample(n=100)
data9_subset = data_9.sample(n=100)

training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data0_testsubset, data1_testsubset, data2_testsubset, data3_testsubset, data4_testsubset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

################### DATA PREP ###################
weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

################### NETWORK TRAINING ###################
error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0
    ################### FW PASS ###################

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    ################### BACK PROPAGATION ###################
    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))


    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

################### NETWORK TESTING ###################

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### OVERALL ERROR GRAPH ###################
fig,axes = plt.subplots()
a = 390
bar_plot = [(a*error_train[len(error_train)-1])/len(train_X), t]
bar_width = 0.5
axes.bar(1.5, bar_plot[0], color="b", width=0.5, label="Train Error")
axes.bar(1.5+bar_width, bar_plot[1], color="g", width=0.5, label="Test Error")
plt.xlim(0,3)
axes.set_xlabel("Errors")
plt.suptitle("Training and Testing Errors")
plt.legend(loc="best")
plt.show()

################### BAR PLOT FOR EACH DIGIT ###################
training_errors = []
testing_errors = []

for i in range(0,5):
    locations = np.where(train_y == i)
    digit_data_train = train_X[locations[0],:]
    st_train_inp_hid_digit = np.dot(digit_data_train, weight_vector_ip_hid)
    hid_op_digit = sigmoid_activation(st_train_inp_hid_digit)
    st_train_hid_op_digit = np.dot(hid_op_digit, weight_vector_hid_op)
    yhat_digit = sigmoid_activation(st_train_hid_op_digit)
    digit_loss = np.sum(np.square(yhat_digit - digit_data_train))/len(digit_data_train)
    training_errors.append(digit_loss)

    digit_data_test = test_X[np.where(test_y == i)]
    st_test_inp_hid_digit = np.dot(digit_data_test, weight_vector_ip_hid)
    hid_op_digit_test = sigmoid_activation(st_test_inp_hid_digit)
    st_test_hid_op_digit = np.dot(hid_op_digit_test, weight_vector_hid_op)
    yhat_digit_test = sigmoid_activation(st_test_hid_op_digit)
    digit_loss_test = np.sum(np.square(yhat_digit_test-digit_data_test))/len(digit_data_test)
    testing_errors.append(digit_loss_test)

fig,axes = plt.subplots()
bar_plot = [training_errors, testing_errors]
indexes = np.arange(len(bar_plot[0]))
br1 = np.arange(len(bar_plot[0]))
br2 = [x + 0.25 for x in br1]
axes.bar(br1, bar_plot[0], color="b", width=0.25, label="Training Errors")
axes.bar(br2, bar_plot[1], color="g", width=0.25, label="Testing Errors")
axes.set_xticks(indexes+0.25)
axes.set_xticklabels(("0","1","2","3","4"))

axes.set_xlabel("Errors")
plt.ylabel("Errors")
plt.xlabel("Digits")
plt.suptitle("Training and Testing Errors of Digits 0-4")
plt.legend(loc="best")
plt.show()

################### GRAPH FOR 5-9 LOSS FUNCTION ###################

data5_subset = data_0.sample(n=100)
data6_subset = data_1.sample(n=100)
data7_subset = data_2.sample(n=100)
data8_subset = data_3.sample(n=100)
data9_subset = data_4.sample(n=100)

testing_set = pd.concat((data5_subset, data6_subset, data7_subset, data8_subset, data9_subset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0
    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))

    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)


testing_errors = []

for i in range(0,5):

    digit_data_test = test_X[np.where(test_y == i)]
    st_test_inp_hid_digit = np.dot(digit_data_test, weight_vector_ip_hid)
    hid_op_digit_test = sigmoid_activation(st_test_inp_hid_digit)
    st_test_hid_op_digit = np.dot(hid_op_digit_test, weight_vector_hid_op)
    yhat_digit_test = sigmoid_activation(st_test_hid_op_digit)
    digit_loss_test = np.sum(np.square(yhat_digit_test-digit_data_test))/len(digit_data_test)
    testing_errors.append(digit_loss_test)

fig,axes = plt.subplots()
bar_plot = [testing_errors]
indexes = np.arange(len(bar_plot[0]))
br1 = np.arange(len(bar_plot[0]))
br2 = [x for x in br1]
axes.bar(br1, bar_plot[0], color="b", width=0.55, label="Testing error")
axes.set_xticks(indexes)
axes.set_xticklabels(("5","6","7","8","9"))

axes.set_xlabel("Errors")
plt.ylabel("Errors")
plt.xlabel("Digits")
plt.suptitle("Testing Errors of Digits 5-9")
plt.legend(loc="best")
plt.show()

training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data0_testsubset, data0_testsubset, data0_testsubset, data0_testsubset, data0_testsubset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))


    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)


st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 0 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 0")
plt.show()



training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data1_testsubset, data1_testsubset, data1_testsubset, data1_testsubset, data1_testsubset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))

    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 1 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 1")
plt.show()


training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data2_testsubset, data2_testsubset, data2_testsubset, data2_testsubset, data2_testsubset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0
    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))


    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 2 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 2")
plt.show()


training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data3_testsubset, data3_testsubset, data3_testsubset, data3_testsubset, data3_testsubset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))

    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 3 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 3")
plt.show()

training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data4_testsubset, data4_testsubset, data4_testsubset, data4_testsubset, data4_testsubset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))


    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 4 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 4")
plt.show()

data5_subset = data_5.sample(n=100)
data6_subset = data_6.sample(n=100)
data7_subset = data_7.sample(n=100)
data8_subset = data_8.sample(n=100)
data9_subset = data_9.sample(n=100)

training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data5_subset, data5_subset, data5_subset, data5_subset, data5_subset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))

    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 5 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 5")
plt.show()


training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data6_subset, data6_subset, data6_subset, data6_subset, data6_subset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds


weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))


error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))


    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 6 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 6")
plt.show()


training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data7_subset, data7_subset, data7_subset, data7_subset, data7_subset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds


weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))


    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 7 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 7")
plt.show()

training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data8_subset, data8_subset, data8_subset, data8_subset, data8_subset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))

    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 8 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 8")
plt.show()


training_set = pd.concat((data0_trainsubset, data1_trainsubset, data2_trainsubset, data3_trainsubset, data4_trainsubset))
training_set = training_set.sample(frac=1)

testing_set = pd.concat((data9_subset, data9_subset, data9_subset, data9_subset, data9_subset))
testing_set = testing_set.sample(frac=1)

train_X = np.array(training_set.iloc[:, :-1])
test_X = np.array(testing_set.iloc[:, :-1])
train_y = np.array(training_set.iloc[:, -1])
test_y = np.array(testing_set.iloc[:, -1])

num_neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds

weight_vector_ip_hid = np.random.randn(784, num_neurons)
weight_vector_hid_op = np.random.randn(num_neurons, 784)
deltaw1 = np.zeros((784,num_neurons))
deltaw2 = np.zeros((num_neurons,784))

error_train = []
eta = 0.001
epochs = 1000
alpha = 0.65
momentum = 1
e = []
for ep in range(0, epochs):
    k = 0
    t = 0

    st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
    hid_op = sigmoid_activation(st_train_inp_hid)
    st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
    yhat = sigmoid_activation(st_train_hid_op)

    temp_dw2 = deltaw2
    deltaw2 = np.dot(hid_op.T,
                     (train_X - yhat) * der_sigmoid(
                         np.dot(hid_op, weight_vector_hid_op)))

    temp_dw1 = deltaw1
    deltaw1 = np.dot(train_X.T, np.dot((train_X - yhat) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                       weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))

    weight_vector_hid_op = weight_vector_hid_op + (eta * deltaw2)
    weight_vector_ip_hid = weight_vector_ip_hid + (eta * deltaw1)

    if ep % 5 == 0:
        for l, m in zip(train_X, yhat):
            k += np.mean((l - m) ** 2)
        k = k / len(train_X)
        error_train.append(k)
        e.append(ep)
        print("Epoch: ",ep,"Train Loss: ",k)

st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
hid_op_test = sigmoid_activation(st_train_inp_hid_test)
st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
yhat_test = sigmoid_activation(st_train_hid_op_test)
for l, m in zip(test_X, yhat_test):
    t += np.sum((l - m) ** 2)
    t = t / len(test_X)
print("\nOver All Test Loss: ", t)

################### DIGIT 9 ###################
test_samples = random.sample(range(499),5)
j = 0
fig, ax = plt.subplots(2, 5)
for k in range(0,5):
    actual = test_X[test_samples[k]].reshape(28,28).T
    predicted = yhat_test[test_samples[k]].reshape(28,28).T
    plt_original = sns.heatmap(actual,ax=ax[j][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    plt_generated = sns.heatmap(predicted, ax=ax[j+1][k], square=True,cbar=False,yticklabels=False,cmap="Blues")
    if k==2:
        plt_original.set_xlabel("Actual Image")
        plt_generated.set_xlabel("Generated Image")

plt.suptitle("Actual and Predicted Images for Digit 9")
plt.show()