################### PROBLEM NUMBER 1 ###################


################### IMPORTS ###################

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix

################### LOAD THE DATA ###################

complete_data = pd.read_csv("MNIST.csv")
data_X = np.array(complete_data.iloc[:, :-1])
data_y = np.array(complete_data.iloc[:, -1])

train_X, test_X, train_y, test_y = train_test_split(data_X, data_y, train_size=0.8)

neurons = 150

def sigmoid_activation(x):
    return 1 / (1 + np.exp(-x))

def der_sigmoid(h):
    h = sigmoid_activation(h)
    ds = h * (1 - h)
    return ds


def NEURAL_NETWORK(c):
    ################### DATA PREPARATION ###################
    weight_vector_ip_hid = np.array(pd.read_csv("W_test.csv", header=None)).T
    weight_vector_hid_op = np.random.randn(neurons, 10)

    ################### ONE HOT ENCODING ###################
    train_y_final = np.zeros((len(train_y), 10))
    for j in range(0, len(train_y)):
        train_y_final[j][train_y[j]] = 1

    test_y_final = np.zeros((len(test_y), 10))
    for j in range(0, len(test_y)):
        test_y_final[j][test_y[j]] = 1

    ################### FOR TRAINING THE MODEL ###################
    error_fraction_train = []
    error_fraction_test = []
    error_train_list = []
    error_test_list = []
    eta = 0.001
    epochs = 1000
    alpha = 0.2
    momentum = 1

    for ep in range(0, epochs):
        cnt_train = 0
        cnt_test = 0
        k = 0
        t = 0
        ################### FWPASS ###################
        st_train_inp_hid = np.dot(train_X, weight_vector_ip_hid)
        hid_op = sigmoid_activation(st_train_inp_hid)
        st_train_hid_op = np.dot(hid_op, weight_vector_hid_op)
        yhat_temp = sigmoid_activation(st_train_hid_op)
        yhat = np.argmax(yhat_temp, axis=1)

        ################### BACKPROPAGATION ###################

        if c == "Case I":
            deltaw2 = np.dot(hid_op.T,
                             (train_y_final - yhat_temp) * der_sigmoid(
                                 np.dot(hid_op, weight_vector_hid_op)))

            weight_vector_hid_op = weight_vector_hid_op + eta * deltaw2

        elif c == "Case II":
            deltaw2 = np.dot(hid_op.T,
                             (train_y_final - yhat_temp) * der_sigmoid(
                                 np.dot(hid_op, weight_vector_hid_op)))

            deltaw1 = np.dot(train_X.T,
                             np.dot((train_y_final - yhat_temp) * der_sigmoid(np.dot(hid_op, weight_vector_hid_op)),
                                    weight_vector_hid_op.T) * (der_sigmoid(np.dot(train_X, weight_vector_ip_hid))))

            weight_vector_hid_op = weight_vector_hid_op + eta * deltaw2
            weight_vector_ip_hid = weight_vector_ip_hid + eta * deltaw1

        ################### H-L METHOD ###################
        for itr in range(0, len(yhat_temp)):
            for l in range(0, 10):
                if yhat_temp[itr][l] >= 0.75:
                    yhat_temp[itr][l] = 1
                elif yhat_temp[itr][l] <= 0.25:
                    yhat_temp[itr][l] = 0

        ################### TEST THE MODEL ###################
        st_train_inp_hid_test = np.dot(test_X, weight_vector_ip_hid)
        hid_op_test = sigmoid_activation(st_train_inp_hid_test)
        st_train_hid_op_test = np.dot(hid_op_test, weight_vector_hid_op)
        yhat_temp_test = sigmoid_activation(st_train_hid_op_test)
        yhat_test = np.argmax(yhat_temp_test, axis=1)

        for itr in range(0, len(yhat_temp_test)):
            for l in range(0, 10):
                if yhat_temp[itr][l] >= 0.75:
                    yhat_temp[itr][l] = 1
                elif yhat_temp[itr][l] <= 0.25:
                    yhat_temp[itr][l] = 0

        if ep % 10 == 0:
            print("Epoch:", ep)
            for l, m in zip(train_y_final, yhat_temp):
                k += sum((l - m) ** 2)
                if np.argmax(l) != np.argmax(m):
                    cnt_train += 1
            k = k / len(train_y_final)
            error_train = cnt_train / len(train_y_final)
            print("Train Loss: ", k)
            print("Train Error Fraction: ", error_train)
            error_fraction_train.append(error_train)
            error_train_list.append(k)

            for l, m in zip(test_y_final, yhat_temp_test):
                t += sum((l - m) ** 2)
                if np.argmax(l) != np.argmax(m):
                    cnt_test += 1
            t = t / len(test_y_final)
            error_test = cnt_test / len(test_y_final)
            print("Test Loss: ", t)
            print("Test Error Fraction: ", error_test)
            error_fraction_test.append(error_test)
            error_test_list.append(t)

    ################### GRAPHS ###################

    df_confusion = confusion_matrix(train_y, yhat)
    plt.title("Confusion Matrix: Train for %s " % c)
    ax = sns.heatmap(df_confusion, annot=True, cbar=False, fmt=".1f")
    ax.xaxis.set_ticks_position('top')
    plt.show()

    df_confusion = confusion_matrix(test_y, yhat_test)
    plt.title("Confusion Matrix: Test For %s " % c)
    ax = sns.heatmap(df_confusion, annot=True, cbar=False, fmt=".1f")
    ax.xaxis.set_ticks_position('top')
    plt.show()

    plt.plot(np.arange(0, (epochs / 10), 1), error_fraction_train, label="Training Error")
    plt.plot(np.arange(0, (epochs / 10), 1), error_fraction_test, label="Testing Error")
    plt.title("Error Fraction vs Epochs For%s " % c)
    plt.xlabel("Epochs")
    plt.ylabel("Error Fractions")
    plt.legend(loc="best")
    plt.show()

    ################### BAR GRAPH ###################

    ################### OVERALL ###################
    fig, axes = plt.subplots()
    bar_plot = [(error_train_list[len(error_train_list) - 1]) / len(train_X), (error_test_list[len(error_test_list) - 1]) / len(test_X)]
    bar_width = 0.5
    axes.bar(1.5, bar_plot[0], color="b", width=0.5, label="Train Error")
    axes.bar(1.5 + bar_width, bar_plot[1], color="g", width=0.5, label="Test Error")
    plt.xlim(0, 3)
    axes.set_xlabel("Errors")
    plt.suptitle("Bar Chart For Errors")
    plt.legend(loc="best")
    plt.show()

    ################### FOR EACH DIGIT ###################
    training_errors = []
    testing_errors = []

    for i in range(0, 10):
        locations = np.where(train_y == i)
        digit_data_train = train_X[locations[0], :]
        st_train_inp_hid_digit = np.dot(digit_data_train, weight_vector_ip_hid)
        hid_op_digit = sigmoid_activation(st_train_inp_hid_digit)
        st_train_hid_op_digit = np.dot(hid_op_digit, weight_vector_hid_op)
        yhat_digit = sigmoid_activation(st_train_hid_op_digit)
        yhat_d = np.argmax(yhat_digit, axis=1)
        digit_loss = np.mean(np.square(yhat_d.reshape(len(yhat_d), 1) - digit_data_train)) / len(digit_data_train)
        training_errors.append(digit_loss)

        digit_data_test = test_X[np.where(test_y == i)]
        st_test_inp_hid_digit = np.dot(digit_data_test, weight_vector_ip_hid)
        hid_op_digit_test = sigmoid_activation(st_test_inp_hid_digit)
        st_test_hid_op_digit = np.dot(hid_op_digit_test, weight_vector_hid_op)
        yhat_digit_test = sigmoid_activation(st_test_hid_op_digit)
        yhat_d_test = np.argmax(yhat_digit_test, axis=1)
        digit_loss_test = np.mean(np.square(yhat_d_test.reshape(len(yhat_d_test), 1) - digit_data_test)) / len(digit_data_test)
        testing_errors.append(digit_loss_test)

    fig, axes = plt.subplots()
    bar_plot = [training_errors, testing_errors]
    indexes = np.arange(len(bar_plot[0]))
    br1 = np.arange(len(bar_plot[0]))
    br2 = [x + 0.25 for x in br1]
    axes.bar(br1, bar_plot[0], color="b", width=0.25, label="Training Error")
    axes.bar(br2, bar_plot[1], color="g", width=0.25, label="Testing Error")
    axes.set_xticks(indexes + 0.25)
    axes.set_xticklabels(("0", "1", "2", "3", "4", "5", "6", "7", "8", "9"))
    axes.set_xlabel("Errors")
    plt.ylabel("Error")
    plt.xlabel("Digits")
    plt.suptitle("Bar Chart For Performance Measures")
    plt.legend(loc="best")
    plt.show()

cases = ["Case 1", "Case 2"]
for c in cases:
    print("--------------------- ", c, " --------------------")
    NEURAL_NETWORK(c)