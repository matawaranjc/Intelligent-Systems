import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

################### PROBLEM NUMBER 1 ###################

################### LOAD THE DATA ###################

img = np.loadtxt('MNISTnumImages5000_balanced.txt')
lbl = np.loadtxt('MNISTnumLabels5000_balanced.txt')
img_data = pd.DataFrame(img)
img_label = pd.DataFrame(lbl)
merge_data = pd.concat((img_data, img_label), axis=1)

################### SEGREGATION OF DATA ###################

num_0 = merge_data.loc[merge_data.iloc[:, -1] == 0]
num_1 = merge_data.loc[merge_data.iloc[:, -1] == 1]
num_2 = merge_data.loc[merge_data.iloc[:, -1] == 2]
num_3 = merge_data.loc[merge_data.iloc[:, -1] == 3]
num_4 = merge_data.loc[merge_data.iloc[:, -1] == 4]
num_5 = merge_data.loc[merge_data.iloc[:, -1] == 5]
num_6 = merge_data.loc[merge_data.iloc[:, -1] == 6]
num_7 = merge_data.loc[merge_data.iloc[:, -1] == 7]
num_8 = merge_data.loc[merge_data.iloc[:, -1] == 8]
num_9 = merge_data.loc[merge_data.iloc[:, -1] == 9]

################### TRAINING, TESTING, & CHALLENGE SETS ###################

num0_trainsub = num_0.iloc[:400, :]
num0_testsub = num_0.iloc[400:, :]
num1_trainsub = num_1.iloc[:400, :]
num1_testsub = num_1.iloc[400:, :]

training_set = pd.concat((num0_trainsub, num1_trainsub))
training_set = training_set.sample(frac=1)
#training_set.to_csv("training_set.csv")

testing_set = pd.concat((num0_testsub, num1_testsub))
testing_set = testing_set.sample(frac=1)
xtrain = np.array(training_set.iloc[:, :-1])
xtest = np.array(testing_set.iloc[:, :-1])
ytrain = np.array(training_set.iloc[:, -1])
ytest = np.array(testing_set.iloc[:, -1]).reshape(200, 1)

data2_subset = num_2.sample(n=100)
data3_subset = num_3.sample(n=100)
data4_subset = num_4.sample(n=100)
data5_subset = num_5.sample(n=100)
data6_subset = num_6.sample(n=100)
data8_subset = num_8.sample(n=100)
data7_subset = num_7.sample(n=100)
data9_subset = num_9.sample(n=100)

challenge_set = pd.concat((data2_subset, data3_subset, data4_subset, data5_subset, data6_subset, data7_subset, data8_subset, data9_subset))
#challenge_set.to_csv("challenge_set.csv")
challenge_set_img = np.array(challenge_set.iloc[:, :-1])
challenge_set_lbl = np.array(challenge_set.iloc[:, -1])

################### NETWORK TRAINING ###################

Vector_weight = np.random.uniform(low=0, high=0.50, size=(1, 784))
Int_Vector_weight = (np.copy(Vector_weight).reshape(28, 28)).T
epoch = np.arange(0, 40, 1)
for ep in range(0, len(epoch)):
    for i in range(0, len(xtrain)):
        z_t = ytrain[i]
        if z_t == 1:
            Vector_weight = Vector_weight + 0.01 * z_t * (
                # using Hebb's Rule
                    xtrain[i] - Vector_weight)
finalWeightVector = (np.copy(Vector_weight).reshape(28, 28)).T

################### NETWORK TESTING ###################

precision = np.zeros((40, 1))
recall = np.zeros((40, 1))
f1_score = np.zeros((40, 1))
optimal = np.arange(0, 40, 1)
y_pred = np.zeros((40, 200))
True_pos = np.zeros((40, 1))
False_pos = np.zeros((40, 1))
True_neg = np.zeros((40, 1))
False_neg = np.zeros((40, 1))

for opt in range(0, len(optimal)):
    for row in range(0, len(xtest)):
        s_t = xtest[row].dot(Vector_weight.T)
        if s_t > opt:
            y_t = 1
            y_pred[opt][row] = y_t
        if y_pred[opt][row] == 1 and ytest[row] == 1:
            True_pos[opt] = True_pos[opt] + 1
        elif y_pred[opt][row] == 0 and ytest[row] == 0:
            True_neg[opt] = True_neg[opt] + 1
        elif y_pred[opt][row] == 1 and ytest[row] == 0:
            False_pos[opt] = False_pos[opt] + 1
        elif y_pred[opt][row] == 0 and ytest[row] == 1:
            False_neg[opt] = False_neg[opt] + 1
    precision[opt] = True_pos[opt] / (True_pos[opt] + False_pos[opt])
    recall[opt] = True_pos[opt] / (True_pos[opt] + False_neg[opt])
    f1_score[opt] = (2 * precision[opt] * recall[opt]) / (precision[opt] + recall[opt])

################### PRECISION, RECALL and F1 SCORE GRAPH ###################

plt.plot(optimal, precision, label="Precision", color = 'red')
plt.plot(optimal, recall, label="Recall", color = 'blue')
plt.plot(optimal, f1_score, label="F1 Score", color = 'green')
plt.xlabel("Theta")
plt.ylabel("Performance Metrics")
plt.legend()
plt.grid()
plt.title("Performance evaluation of the optimal threshold (θ)")
plt.show()

################### ROC CURVE ###################

plt.plot(False_pos, True_pos)
plt.legend(loc="lower right")
plt.xlabel("False Positives")
plt.ylabel("True Positives")
plt.grid()
plt.title("Receiver Operating Characteristic (ROC) curve")
plt.show()

################### HEATMAP ###################

fig, (ax1, ax2) = plt.subplots(1, 2)
plt_initial = sns.heatmap(Int_Vector_weight, ax=ax1, square=True)
plt_final = sns.heatmap(finalWeightVector, ax=ax2, square=True)
plt.suptitle("Heatmap: Weight Density")
plt_initial.set_xlabel("Initial Weights")
plt_final.set_xlabel("Final Weights")
plt.show()

################### PRECISION, RECALL and F1 SCORE GRAPH ###################

n02=n03=n04=n05=n06=n07=n08=n09=n12=n13=n14=n15=n16=n17=n18=n19=0

ypred_challenge = np.zeros((800, 1))
for row in range(0, len(challenge_set_img)):
    st_challenge = challenge_set_img[row].dot(Vector_weight.T)
    if st_challenge > 22:
        ypred_challenge[row] = 1
    if ypred_challenge[row] == 1 and challenge_set_lbl[row] == 2:
        n12 = n12 + 1
    elif ypred_challenge[row] == 1 and challenge_set_lbl[row] == 3:
        n13 = n13 + 1
    elif ypred_challenge[row] == 1 and challenge_set_lbl[row] == 4:
        n14 = n14 + 1
    elif ypred_challenge[row] == 1 and challenge_set_lbl[row] == 5:
        n15 = n15 + 1
    elif ypred_challenge[row] == 1 and challenge_set_lbl[row] == 6:
        n16 = n16 + 1
    elif ypred_challenge[row] == 1 and challenge_set_lbl[row] == 7:
        n17 = n17 + 1
    elif ypred_challenge[row] == 1 and challenge_set_lbl[row] == 8:
        n18 = n18 + 1
    elif ypred_challenge[row] == 1 and challenge_set_lbl[row] == 9:
        n19 = n19 + 1
    elif ypred_challenge[row] == 0 and challenge_set_lbl[row] == 2:
        n02 = n02 + 1
    elif ypred_challenge[row] == 0 and challenge_set_lbl[row] == 3:
        n03 = n03 + 1
    elif ypred_challenge[row] == 0 and challenge_set_lbl[row] == 4:
        n04 = n04 + 1
    elif ypred_challenge[row] == 0 and challenge_set_lbl[row] == 5:
        n05 = n05 + 1
    elif ypred_challenge[row] == 0 and challenge_set_lbl[row] == 6:
        n06 = n06 + 1
    elif ypred_challenge[row] == 0 and challenge_set_lbl[row] == 7:
        n07 = n07 + 1
    elif ypred_challenge[row] == 0 and challenge_set_lbl[row] == 8:
        n08 = n08 + 1
    elif ypred_challenge[row] == 0 and challenge_set_lbl[row] == 9:
        n09 = n09 + 1

print("Challenge Set Implementation: Problem #1")
matrix_chall_P1 = pd.DataFrame(
    np.array([[n02, n03, n04, n05, n06, n07, n08, n09], [n12, n13, n14, n15, n16, n17, n18, n19]]),
    columns=["2", "3", "4", "5", "6", "7", "8", "9"])
print(matrix_chall_P1)

################### PROBLEM NUMBER 2 ###################

################### LOAD THE DATA ###################

train2_set = training_set
test2_set = testing_set
challenge2_set = challenge_set

################### PREPARATION OF DATA ###################

x_train2 = np.array(train2_set.iloc[:, :-1])
y_train2 = np.array(train2_set.iloc[:, -1]).reshape((800, 1))
x_test2 = np.array(test2_set.iloc[:, :-1])
y_test2 = np.array(test2_set.iloc[:, -1]).reshape((200, 1))
weight_vector = np.random.uniform(low=0, high=0.5, size=(1, 785))
bias = np.ones((800, 1))
x_train_final = np.append(x_train2, bias, axis=1)
x_test_final = np.append(x_test2, bias[:200, :], axis=1)

################### BEFORE TRAINING PERFORMANCE ###################

In_TN = 0
In_FN = 0
In_TP = 0
In_FP = 0

for i in range(0, len(x_train2)):
    st_trainIni = x_train_final[i].dot(weight_vector.T)
    if st_trainIni > 0:
        y_t_trainIni = 1
    else:
        y_t_trainIni = 0
    if int(y_t_trainIni) == 1 and y_train2[i] == 1:
        In_TP = In_TP + 1
    elif int(y_t_trainIni) == 1 and y_train2[i] == 0:
        In_FP = In_FP + 1
    elif int(y_t_trainIni) == 0 and y_train2[i] == 1:
        In_FN = In_FN + 1
    elif int(y_t_trainIni) == 0 and y_train2[i] == 0:
        In_TN = In_FN + 1
if (In_TP + In_FP) == 0:
    print("Divide by zero exception error")
else:
    In_precision = In_TP / (In_TP + In_FP)
    In_recall = In_TP / (In_TP + In_FN)
if (In_precision + In_recall) == 0:
    print("Divide by zero exception error")
else:
    In_F1 = (2 * In_precision * In_recall) / (In_precision + In_recall)

print("Before Training:")
print("Precision: ", In_precision)
print("Recall: ", In_recall)
print("F1-Score: ", In_F1)

################### NETWORK TRAINING ###################

epoch2 = np.arange(0, 68, 1)
errorfract_train = []
Errorfract_test = []
Weight_vectorInitial = weight_vector[:, :-1].reshape(28, 28).T

for ep in range(0, len(epoch2)):
    cnt_train = 0
    cnt_test = 0
    for i in range(0, 800):
        st_train = x_train_final[i].dot(weight_vector.T)
        if st_train > 0:
            ytTrain = 1
        else:
            ytTrain = 0
        weight_vector = weight_vector + 0.0001 * (y_train2[i] - ytTrain) * x_train_final[i]
        if ytTrain != y_train2[i]:
            cnt_train += 1
    for t in range(0, 200):
        st_test = x_test_final[t].dot(weight_vector.T)
        if st_test > 0:
            ytTest = 1
        else:
            ytTest = 0
        if int(ytTest) != y_test2[t]:
            cnt_test += 1
    errorf_train = cnt_train / 800
    errorf_test = cnt_test / 200
    errorfract_train.append(errorf_train)
    Errorfract_test.append(errorf_test)
finalWeightVector = weight_vector[:, :-1].reshape(28, 28).T

################### EPOCHS AGAINST THE TRAINING ERROR AND THE TEST ERROR FRACTIONS ###################

plt.plot(epoch2, errorfract_train, color="blue", label="Train Error Fraction")
plt.plot(epoch2, Errorfract_test, color="red", label="Test Error Fraction")
plt.legend()
plt.grid()
plt.xlabel("Epochs")
plt.ylabel("Error Fractions")
plt.title("Epochs Vs Error Fractions")
plt.show()

################### AFTER TRAINING PERFORMANCE ###################

Fn_TP = 0
Fn_FP = 0
Fn_TN = 0
Fn_FN = 0

for i in range(0, len(x_train2)):
    trainFn_y = x_train_final[i].dot(weight_vector.T)
    if int(trainFn_y) == 1 and y_train2[i] == 1:
        Fn_TP = Fn_TP + 1
    elif int(trainFn_y) == 1 and y_train2[i] == 0:
        Fn_FP = Fn_FP + 1
    elif int(trainFn_y) == 0 and y_train2[i] == 1:
        Fn_FN = Fn_FN + 1
    elif int(trainFn_y) == 0 and y_train2[i] == 0:
        Fn_TN = Fn_TN + 1
if (Fn_TP + Fn_FP) == 0:
    print("Divide by zero exception error")
else:
    FN_Precision = Fn_TP / (Fn_TP + Fn_FP)
    FN_Recall = Fn_TP / (Fn_TP + Fn_FN)
if (FN_Precision + FN_Recall) == 0:
    print("Divide by Zero Exception error")
else:
    FN_F1Score = (2 * FN_Precision * FN_Recall) / (FN_Precision + FN_Recall)

print("\nAfter Training:")
print("Precision: ", FN_Precision)
print("Recall: ", FN_Recall)
print("F1-Score: ", FN_F1Score)

################### PERFORMANCE EVALUATION ###################

fig, axes = plt.subplots()
bar_plot = [[In_precision, FN_Precision], [In_recall, FN_Recall], [In_F1, FN_F1Score]]
indexes = np.arange(len(bar_plot[0]))
labels = [["Initial Precision", "Final Precision"], ["Initial Recall", "Final Recall"],
          ["Initial F1-Score", "Final F1-Score"]]
BR_1 = np.arange(len(bar_plot[0]))
BR_2 = [x + 0.15 for x in BR_1]
BR_3 = [x + 0.15 for x in BR_2]
axes.bar(BR_1, bar_plot[0], color="yellow", width=0.15, label="Precisoins")
axes.bar(BR_2, bar_plot[1], color="orange", width=0.15, label="Recall")
axes.bar(BR_3, bar_plot[2], color="green", width=0.15, label="F1 Score")
axes.set_xticks(indexes + 0.15)
axes.set_xticklabels(("Before Training", "After Training"))
axes.set_xlabel("Performance Evaluation")
plt.suptitle("Paired Bar Chart For Performance Evaluation")
plt.legend(loc="lower center")
plt.show()

################### CHALLENGE SET IMPLEMENTATION ###################
num2_12 = num2_13 = num2_14 = num2_15 = num2_16 = num2_17 = num2_18 = num2_19 = 0
num2_02 = num2_03 = num2_04 = num2_05 = num2_06 = num2_07 = num2_08 = num2_09 = 0
challenge2_x = np.array(challenge2_set.iloc[:, :-1])
challenge2_y = np.array(challenge2_set.iloc[:, -1])
final_challenge2_x = np.append(challenge2_x, bias[:800, :], axis=1)
for row in range(0, len(challenge2_x)):
    challenge2_st = final_challenge2_x[row].dot(weight_vector.T)
    if challenge2_st > 0:
        chall_y2 = 1
    else:
        chall_y2 = 0
    if int(chall_y2) == 1 and challenge2_y[row] == 2:
        num2_12 = num2_12 + 1
    elif int(chall_y2) == 0 and challenge2_y[row] == 2:
        num2_02 = num2_02 + 1
    elif int(chall_y2) == 1 and challenge2_y[row] == 3:
        num2_13 = num2_13 + 1
    elif int(chall_y2) == 0 and challenge2_y[row] == 3:
        num2_03 = num2_03 + 1
    elif int(chall_y2) == 1 and challenge2_y[row] == 4:
        num2_14 = num2_14 + 1
    elif int(chall_y2) == 0 and challenge2_y[row] == 4:
        num2_04 = num2_04 + 1
    elif int(chall_y2) == 1 and challenge2_y[row] == 5:
        num2_15 = num2_15 + 1
    elif int(chall_y2) == 0 and challenge2_y[row] == 5:
        num2_05 = num2_05 + 1
    elif int(chall_y2) == 1 and challenge2_y[row] == 6:
        num2_16 = num2_16 + 1
    elif int(chall_y2) == 0 and challenge2_y[row] == 6:
        num2_06 = num2_06 + 1
    elif int(chall_y2) == 1 and challenge2_y[row] == 7:
        num2_17 = num2_17 + 1
    elif int(chall_y2) == 0 and challenge2_y[row] == 7:
        num2_07 = num2_07 + 1
    elif int(chall_y2) == 1 and challenge2_y[row] == 8:
        num2_18 = num2_18 + 1
    elif int(chall_y2) == 0 and challenge2_y[row] == 8:
        num2_08 = num2_08 + 1
    elif int(chall_y2) == 1 and challenge2_y[row] == 9:
        num2_19 = num2_19 + 1
    elif int(chall_y2) == 0 and challenge2_y[row] == 9:
        num2_09 = num2_09 + 1

print("Challenge Set Implementation: Problem #2")
matrix_challP2 = pd.DataFrame(
    np.array([[num2_02, num2_03, num2_04, num2_05, num2_06, num2_07, num2_08, num2_09], [num2_12, num2_13, num2_14, num2_15, num2_16, num2_17, num2_18, num2_19]]),
    columns=["2", "3", "4", "5", "6", "7", "8", "9"])
print(matrix_challP2)

################### HEATMAP ###################

fig, (ax1, ax2) = plt.subplots(1, 2)
plt_initial = sns.heatmap(Weight_vectorInitial, ax=ax1, square=True, vmax=1, vmin=0)
plt_final = sns.heatmap(finalWeightVector, ax=ax2, square=True, vmax=1, vmin=0)
plt.suptitle("Heatmap: Weight Density")
plt_initial.set_xlabel("Initial Weights")
plt_final.set_xlabel("Final Weights")
plt.show()

